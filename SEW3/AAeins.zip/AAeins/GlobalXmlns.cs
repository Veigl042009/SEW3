[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "AAeins")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "AAeins.Pages")]
