﻿using HÜ05_01;
using System.Globalization;
Console.OutputEncoding = System.Text.Encoding.UTF8;

Console.WriteLine($"Der gesamte Preis der Herde an Schweinen ist:  {PigRevenue.PriceOfTheHerd()} €");


