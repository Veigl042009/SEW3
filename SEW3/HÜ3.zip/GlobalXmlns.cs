[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "hueDrei")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "hueDrei.Pages")]
